#Cantar palabras
palabras = ["Python", "Java", "C++", "Python", "JavaScript", "Python", "C#"]
contador = 0
for palabra in palabras:
    if palabra == "Python":
        contador += 1
print(contador)
#Convertir
frases = ["hola", "mundo", "python", "es", "genial"]
mayusculas = []
for frase in frases:
    mayuscula = ""
    for letra in frase:
        mayuscula += chr(ord(letra) - 32)
    mayusculas.append(mayuscula)
print(mayusculas)
#eliminar
palabras = ["sol", "luna", "cielo", "mar", "estrella", "pez"]
palabras_filtradas = []
for palabra in palabras:
    if len(palabra) >= 4:
        palabras_filtradas.append(palabra)
print(palabras_filtradas)
#encontrar numero max
numeros = [15, 22, 8, 34, 9, 6, 17]
maximo = numeros[0]
for numero in numeros:
    if numero > maximo:
        maximo = numero
print(maximo)
#numeros positivos
numeros = [-3, 5, -7, 2, -8, 10, -4, 6]
contador = 0
for numero in numeros:
    if numero > 0:
        contador += 1
print(contador)
#invertir el orden 
numeros = [1, 2, 3, 4, 5]
inversa = []
for i in range(len(numeros)-1, -1, -1):
    inversa.append(numeros[i])
print(inversa)
#encontrar la media
numeros = [4, 7, 2, 9, 3, 8, 5]
suma = 0
for numero in numeros:
    suma += numero
media = suma / len(numeros)
print(media)