#suma de matrices
def sumar_matrices(matriz1, matriz2):
    filas = len(matriz1)
    columnas = len(matriz1[0])
    resultado = []
    for i in range(filas):
        fila = []
        for j in range(columnas):
            suma = matriz1[i][j] + matriz2[i][j]
            fila.append(suma)
        resultado.append(fila)
    return resultado

# Ejemplo de uso
matriz1 = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
matriz2 = [[9, 8, 7], [6, 5, 4], [3, 2, 1]]
resultado = sumar_matrices(matriz1, matriz2)
print(resultado)
# multiplicaciones
def multiplicar_matrices(matriz1, matriz2):
    filas1 = len(matriz1)
    columnas1 = len(matriz1[0])
    filas2 = len(matriz2)
    columnas2 = len(matriz2[0])
    if columnas1 != filas2:
        return "No se pueden multiplicar las matrices"
    resultado = []
    for i in range(filas1):
        fila = []
        for j in range(columnas2):
            suma = 0
            for k in range(columnas1):
                suma += matriz1[i][k] * matriz2[k][j]
            fila.append(suma)
        resultado.append(fila)
    return resultado

# Ejemplo de uso
matriz1 = [[1, 2], [3, 4], [5, 6]]
matriz2 = [[7, 8, 9], [10, 11, 12]]
resultado = multiplicar_matrices(matriz1, matriz2)
print(resultado)
#trasnposicion
def transponer_matriz(matriz):
    filas = len(matriz)
    columnas = len(matriz[0])
    resultado = []
    for j in range(columnas):
        fila = []
        for i in range(filas):
            fila.append(matriz[i][j])
        resultado.append(fila)
    return resultado

# Ejemplo de uso
matriz = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]
resultado = transponer_matriz(matriz)
print(resultado)
#verificacion
def es_cuadrado_magico(matriz):
    filas = len(matriz)
    columnas = len(matriz[0])
    suma_diagonal1 = 0
    suma_diagonal2 = 0
    for i in range(filas):
        suma_fila = 0
        suma_columna = 0
        for j in range(columnas):
            suma_fila += matriz[i][j]
            suma_columna += matriz[j][i]
            if i == j:
                suma_diagonal1 += matriz[i][j]
            if i + j == filas - 1:
                suma_diagonal2 += matriz[i][j]
        if suma_fila != suma_columna:
            return False
    if suma_diagonal1 != suma_diagonal2:
        return False
    return True

# Ejemplo de uso
matriz = [[2, 7, 6], [9, 5, 1], [4, 3, 8]]
if es_cuadrado_magico(matriz):
    print("La matriz es un cuadrado mágico")
else:
    print("La matriz no es un cuadrado mágico")