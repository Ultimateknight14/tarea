#saludo
def saludar(nombre):
    return f"Hola, {nombre}"
print(saludar("Moisés"))
#area circulo
import math
def area_circulo(radio):
    return math.pi * radio ** 2
print(area_circulo(5))
#millas akilometros
def millas_a_kilometros(millas):
    return millas * 1.60934
print(millas_a_kilometros(10))
#repetir texto
def repetir_texto(texto, veces):
    return texto * veces
print(repetir_texto("Hola", 3))
#multiplicacion simple
def multiplicar(a, b):
    return a * b
print(multiplicar(5, 7))
#mayusculas y minusculas
def cambiar_caso(texto):
    return texto.swapcase()
print(cambiar_caso("Hola Mundo"))
#calcular perimetro del rectangulo
def perimetro_rectangulo(largo, ancho):
    return 2 * (largo + ancho)
print(perimetro_rectangulo(5, 7))