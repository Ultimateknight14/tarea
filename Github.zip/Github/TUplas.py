
#act1 •	Creación de una tupla
def crear_tupla(num1, num2, num3):
    return (num1, num2, num3)   
#act2
numeros = (10, 20, 30, 40, 50)
tercer_elemento = numeros[2]
print(tercer_elemento)
#act3
tupla_anidada = ((1, 2, 3), (4, 5, 6), (7, 8, 9))
numero_5 = tupla_anidada[1][1]
print(numero_5)
#act4
pares = (2, 4, 6, 8, 10)
impares = (1, 3, 5, 7, 9)
numeros = pares + impares
print(numeros)
#act5
colores = ('rojo', 'azul', 'verde', 'rojo', 'amarillo', 'rojo')
contador_rojo = colores.count('rojo')
print(contador_rojo)
#act6
nombres = ['Ana', 'Juan', 'Pedro', 'Luis']
tupla_nombres = tuple(nombres)
print(tupla_nombres)
#act7
tupla_larga = (1, 2, 3, 4, 5, 6, 7, 8, 9, 10)
primeros_cinco = tupla_larga[:5]
print(primeros_cinco)
#act8
a = 5
b = 10
print(f"Antes del intercambio: a = {a}, b = {b}")
a, b = b, a
print(f"Después del intercambio: a = {a}, b = {b}")